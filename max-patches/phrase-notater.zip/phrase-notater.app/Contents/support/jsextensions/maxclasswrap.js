maxclasswrap("dictwrap", "Dict");
maxclasswrap("packages", "Packages");
maxclasswrap("polybuffer", "PolyBuffer");
maxclasswrap("mixer_gaincontrol", "MSPMixerGainControl");
maxclasswrap("mixer_audiometer", "MSPMixerAudioMeter");
maxclasswrap("mixer_cpumeter", "MSPMixerCPUMeter");
maxclasswrap("mixer_global", "MSPMixerGlobal");
